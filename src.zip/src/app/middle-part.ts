import { Component } from "@angular/core";

@Component({
    selector:'app-middle',
    standalone: true,
    template:`
    <div class="mid">
        <div class="container">
            <div class="visual-side">
                <div class="skewed-square"></div>
                <img src="/assets/pictures/IMG_20250704_133407-1.jpg" alt="Your photo" class="overlapping-image">
            </div>
            <div class="text-side">
                <div class="text-container">
                    <p class="text">Welcome, I code sites and analyse data as a data scientist</p>
                </div>
            </div>
        </div>
    </div>`,
    styles:[`
    .mid {
        position: relative;
        width: 100%;
        height: 500px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 100px auto;
    }

    .container {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 1000px;
        gap: 100px;
    }
    
    .visual-side {
        position: relative;
        flex-shrink: 0;
        width: 350px; 
        height: 350px; 
    }

    .text-side {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align text to the left within its container */
    }
    
    .text-container {
        max-width: 500px;
    }

    .text {
        font-size: 20px;
        line-height: 1.6;
        margin: 0;
        color: white;
        font-family: 'Arial', sans-serif;
        font-weight: 500;
    }
    
    .skewed-square {
        width: 350px;
        height: 350px;
        background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
        transform: skew(500deg, -10deg) rotate(10deg);
        position: absolute;
        z-index: 1;
        border-radius: 15px;
        transition: all 0.7s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        transform-origin: center; 
        top: 0;
        left: 0;
    }
    
    .overlapping-image {
        width: 300px;
        height: 300px;
        object-fit: cover;
        position: absolute;
        z-index: 2;
        border-radius: 10px;
        transform: translate(20px, -15px) rotate(-5deg); 
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        top: 8%;
        left: 0;
    }

    .skewed-square:hover {
        transform: skew(-8deg, -8deg) rotate(8deg) scale(0.95);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
    }
    
    .overlapping-image:hover {
        transform: translate(20px, -15px) rotate(-3deg) scale(1.02);
        box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
    }
    
    /* Animation on page load */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .mid {
        animation: fadeInUp 0.8s ease-out;
    }
    
    /* Mobile responsiveness */
    @media (max-width: 768px) {
        .mid {
            height: auto;
            min-height: 500px;
            margin: 80px auto;
            padding: 20px;
        }
        
        .container {
            flex-direction: column;
            gap: 40px;
            text-align: center;
        }
        
        .visual-side {
            width: 280px;
            height: 280px;
        }
        
        .skewed-square {
            width: 280px;
            height: 280px;
            transform: skew(-8deg, -8deg) rotate(8deg);
        }
        
        .overlapping-image {
            width: 250px;
            height: 250px;
            transform: translate(15px, -10px) rotate(-4deg);
        }
        
        .text {
            font-size: 1.3rem;
        }
        
        .text-side {
            justify-content: center;
        }
    }
    
    @media (max-width: 480px) {
        .mid {
            height: auto;
            min-height: 450px;
            margin: 60px auto;
        }
        
        .visual-side {
            width: 220px;
            height: 220px;
        }
        
        .skewed-square {
            width: 220px;
            height: 220px;
            transform: skew(-5deg, -5deg) rotate(5deg);
        }
        
        .overlapping-image {
            width: 190px;
            height: 190px;
            transform: translate(10px, -8px) rotate(-3deg);
        }
        
        .text {
            font-size: 1.1rem;
        }
    }
    `]
})
export class midcomponent{}